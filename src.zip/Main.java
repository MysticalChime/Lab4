import java.util.*;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) {

        Scanner scanner = new Scanner(System.in);

        int carMpg;
        double carTankCapacity;
        double percentGas;
        int rawRange;

        System.out.println("Enter your car's MPG rating (miles/gallon) as a positive integer.");
        carMpg = scanner.nextInt();

        if (carMpg <= 0) {
            System.out.println("ERROR: ONLY POSITIVE INTEGERS ARE ACCEPTED FOR MPG!!!");
            System.exit(0);

        }
        System.out.println("Enter your car's tank capacity (gallons) as a postive decimal number:");
        carTankCapacity = scanner.nextDouble();

        if (carTankCapacity <= 0.0) {
            System.out.println("ERROR: ONLY POSITIVE DECIMAL NUMBERS ARE ACCEPTED FOR TANK CAPACITY!!!");
            System.exit(0);
        }

        System.out.println("Enter the percentage of the gas tank that is currently filled (from 0-100%):");
        percentGas = scanner.nextDouble();

        if (percentGas < 0.0) {
            System.out.println("ERROR: PERCENTAGE MUST BE A DECIMAL NUMBER IN THE RANGE OF 0-100 (INCLUSIVE)!!!");
            System.exit(0);
        }

         rawRange = (int)(carMpg * carTankCapacity * (percentGas * 0.01));

         if (rawRange <= 25) {
             System.out.println("Attention! Your current estimated range is running low: " + rawRange + "miles left!!!");
         }
         else {
             System.out.println("Keep driving! Your current estimate range is: " + rawRange + "miles!");
         }








        }

    }









